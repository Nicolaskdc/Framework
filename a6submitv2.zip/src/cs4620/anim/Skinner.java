package cs4620.anim;

public class Skinner {

}
