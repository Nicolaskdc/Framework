package cs4620.scene.form;

public interface ValueUpdatable {
	void updateValues();
}
