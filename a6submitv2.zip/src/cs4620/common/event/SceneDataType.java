package cs4620.common.event;

public enum SceneDataType {
	Mesh,
	Texture,
	Material,
	Object,
	Cubemap,
	None
}
