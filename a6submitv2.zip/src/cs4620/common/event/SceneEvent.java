package cs4620.common.event;

public class SceneEvent {
	public final SceneDataType dataType;
	
	public SceneEvent(SceneDataType t) {
		dataType = t;
	}
	
}
