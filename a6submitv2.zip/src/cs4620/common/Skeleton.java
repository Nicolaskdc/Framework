package cs4620.common;


public class Skeleton {
	public static final int MAX_BONES = 32;
	
}
